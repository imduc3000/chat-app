#include <stdio.h>
#include <math.h>

// Hàm kiểm tra số Armstrong
int isArmstrong(int num) {
    int originalNum = num;
    int n = 0;
    int sum = 0;

    // Đếm số chữ số
    while (originalNum != 0) {
        originalNum /= 10;
        n++;
    }

    originalNum = num; // Đặt lại giá trị ban đầu của số

    // Tính tổng lũy thừa bậc n của các chữ số
    while (originalNum != 0) {
        int digit = originalNum % 10;
        sum += pow(digit, n);
        originalNum /= 10;
    }

    // Kiểm tra xem tổng có bằng số ban đầu không
    return sum == num;
}

int main() {
    int n;

    // Yêu cầu người dùng nhập số và kiểm tra đầu vào
    do {
        printf("Please enter a number (n > 0): ");
        scanf("%d", &n);

        if (n <= 0) {
            printf("Invalid input. Please enter a positive integer.\n");
        }
    } while (n <= 0); // Lặp lại nếu đầu vào không hợp lệ

    // In các số Armstrong từ 1 đến n bằng vòng lặp for
    printf("Armstrong numbers (using for loop): ");
    for (int i = 1; i <= n; i++) {
        if (isArmstrong(i)) {
            printf("%d ", i);
        }
    }
    printf("\n");

    // In các số Armstrong từ 1 đến n bằng vòng lặp while
    printf("Armstrong numbers (using while loop): ");
    int i = 1;
    while (i <= n) {
        if (isArmstrong(i)) {
            printf("%d ", i);
        }
        i++;
    }
    printf("\n");

    // In các số Armstrong từ 1 đến n bằng vòng lặp do-while
    printf("Armstrong numbers (using do-while loop): ");
    i = 1;
    do {
        if (isArmstrong(i)) {
            printf("%d ", i);
        }
        i++;
    } while (i <= n);
    printf("\n");

    return 0;
}