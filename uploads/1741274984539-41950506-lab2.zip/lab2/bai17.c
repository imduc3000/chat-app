#include <stdio.h>

// Hàm kiểm tra số hoàn hảo
int isPerfect(int num) {
    int sum = 0;

    // Tìm các ước số của num và tính tổng
    for (int i = 1; i < num; i++) {
        if (num % i == 0) {
            sum += i;
        }
    }

    // Kiểm tra xem tổng có bằng num không
    return sum == num;
}

int main() {
    int n;

    // Yêu cầu người dùng nhập số và kiểm tra đầu vào
    do {
        printf("Please enter a number (n > 0): ");
        scanf("%d", &n);

        if (n <= 0) {
            printf("Invalid input. Please enter a positive integer.\n");
        }
    } while (n <= 0); // Lặp lại nếu đầu vào không hợp lệ

    // In các số hoàn hảo từ 1 đến n bằng vòng lặp for
    printf("Perfect numbers (using for loop): ");
    for (int i = 1; i <= n; i++) {
        if (isPerfect(i)) {
            printf("%d ", i);
        }
    }
    printf("\n");

    // In các số hoàn hảo từ 1 đến n bằng vòng lặp while
    printf("Perfect numbers (using while loop): ");
    int i = 1;
    while (i <= n) {
        if (isPerfect(i)) {
            printf("%d ", i);
        }
        i++;
    }
    printf("\n");

    // In các số hoàn hảo từ 1 đến n bằng vòng lặp do-while
    printf("Perfect numbers (using do-while loop): ");
    i = 1;
    do {
        if (isPerfect(i)) {
            printf("%d ", i);
        }
        i++;
    } while (i <= n);
    printf("\n");

    return 0;
}