#include <stdio.h>
#include <math.h>

int main() {
    int i, n, m, sc, count = 0, sum = 0;

    // Nhập số từ người dùng
    printf("Enter a number: ");
    scanf("%d", &n);

    m = n; // Lưu giá trị ban đầu của n vào m

    // Đếm số chữ số của n
    do {
        sc = n % 10;
        count += 1;
        n /= 10;
    } while (n != 0);

    // Tính tổng lũy thừa bậc count của các chữ số
    n = m; // Đặt lại giá trị ban đầu của n
    for (i = 1; i <= count; i++) {
        sc = n % 10;
        n /= 10;
        sum += pow(sc, count);
    }

    // So sánh tổng với số ban đầu và in kết quả
    if (sum == m) {
        printf("%d is an Armstrong number.\n", m);
    } else {
        printf("%d is NOT an Armstrong number.\n", m);
    }

    return 0;
}