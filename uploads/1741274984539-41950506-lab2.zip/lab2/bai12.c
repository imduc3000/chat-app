#include <stdio.h>
#include <math.h>

void check_prime(int n) {
    if (n < 2) {
        printf("This is NOT a Prime number\n");
        return;
    }
    if (n == 2) {
        printf("This is a Prime number\n");
        return;
    }
    if (n % 2 == 0) {
        printf("This is NOT a Prime number\n");
        return;
    }

    for (int i = 3; i <= sqrt(n); i += 2) {
        if (n % i == 0) {
            printf("This is NOT a Prime number\n");
            return;
        }
    }
    
    printf("This is a Prime number\n");
}

int main() {
    int a;
    printf("Please enter a number: ");
    scanf("%d", &a);

    if (a < 0) {
        printf("Invalid input (negative number). Please enter a non-negative number!\n");
        return 1; // Kết thúc chương trình nếu nhập số âm
    }

    check_prime(a);
    return 0;
}