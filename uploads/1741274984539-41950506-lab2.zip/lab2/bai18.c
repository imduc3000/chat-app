#include <stdio.h>

void decimalToBinary(int n) {
    int binaryDigit;
    long long binaryNumber = 0;
    int placeValue = 1;

    // Chuyển đổi số thập phân sang nhị phân
    while (n > 0) {
        binaryDigit = n % 2;
        binaryNumber += binaryDigit * placeValue;
        placeValue *= 10;
        n = n / 2;
    }

    // In kết quả
    printf("Binary number: %lld\n", binaryNumber);
}

int main() {
    int n;

    // Yêu cầu người dùng nhập số và kiểm tra đầu vào
    do {
        printf("Please enter a non-negative integer: ");
        scanf("%d", &n);

        if (n < 0) {
            printf("Invalid input. Please enter a non-negative integer.\n");
        }
    } while (n < 0); // Lặp lại nếu đầu vào không hợp lệ

    decimalToBinary(n);

    return 0;
}