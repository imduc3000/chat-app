#include <stdio.h>

int main() {
    int n, sum = 0, i;
    do {
        printf("Nhap gia tri cua n: ");
        scanf("%d", &n);

        if (n <= 0)
        {
            printf("Gia tri khong hop le. Vui long nhap lai! \n");
        }
        
    } while (n <= 0);
    
    for (i = 1; i <= n; i+= 2)
    {
        sum += i;
    }    
    printf("Tong for: %d \n", sum);

    sum = 0;
    i = 1;
    while (i <= n) {
        sum += i;
        i += 2;
    }
    printf("Tong while: %d \n", sum);

    sum = 0;
    i = 1;
    do
    {
        sum += i;
        i += 2;
    } while (i <= n);
    printf("Tong while: %d \n", sum);

    return 0;
}