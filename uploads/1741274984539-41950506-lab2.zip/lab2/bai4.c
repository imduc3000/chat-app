#include <stdio.h>

int main() {
    int n, sum = 0;
    do {
        printf("Nhap gia tri cua n: ");
        scanf("%d", &n);

        if (n <= 0)
        {
            printf("Gia tri khong hop le. Vui long nhap lai! \n");
        }
        
    } while (n <= 0);
    
    for (int i = 1; i <= n; i++)
    {
        sum += i;
    }    
    
    printf("Tong cua cac so tu 1 toi %d la: %d \n",n ,sum);

    return 0;
}