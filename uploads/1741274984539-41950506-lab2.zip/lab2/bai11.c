#include <stdio.h>

int main() {
    int n, m, sc, sum = 0; 
    
    printf("Please enter a number: ");
    scanf("%d", &n);
    
    m = n;
    
    int sd = 0;
    
    while (n != 0)
    {   
        sc = n % 10;
        sd = sc + sd * 10;
        n /= 10;
    }

    if (m == sd) {
        printf("This is a palindrome number");
    } else {
        printf("This is NOT a palindrome number");
    }
    
    return 0;
}