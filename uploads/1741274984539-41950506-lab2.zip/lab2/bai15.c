#include <stdio.h>
#include <math.h>

// Hàm kiểm tra số nguyên tố
int isPrime(int num) {
    if (num < 2) return 0; // Số nhỏ hơn 2 không phải số nguyên tố
    if (num == 2) return 1; // 2 là số nguyên tố
    if (num % 2 == 0) return 0; // Số chẵn lớn hơn 2 không phải số nguyên tố

    for (int i = 3; i <= sqrt(num); i += 2) {
        if (num % i == 0) return 0; // Nếu có ước số, không phải số nguyên tố
    }
    return 1; // Là số nguyên tố
}

int main() {
    int n;

    // Yêu cầu người dùng nhập số và kiểm tra đầu vào
    do {
        printf("Please enter a number (n > 0): ");
        scanf("%d", &n);

        if (n <= 0) {
            printf("Invalid input. Please enter a positive integer.\n");
        }
    } while (n <= 0); // Lặp lại nếu đầu vào không hợp lệ

    // In các số nguyên tố từ 1 đến n bằng vòng lặp for
    printf("Prime numbers (using for loop): ");
    for (int i = 2; i <= n; i++) {
        if (isPrime(i)) {
            printf("%d ", i);
        }
    }
    printf("\n");

    // In các số nguyên tố từ 1 đến n bằng vòng lặp while
    printf("Prime numbers (using while loop): ");
    int i = 2;
    while (i <= n) {
        if (isPrime(i)) {
            printf("%d ", i);
        }
        i++;
    }
    printf("\n");

    // In các số nguyên tố từ 1 đến n bằng vòng lặp do-while
    printf("Prime numbers (using do-while loop): ");
    i = 2;
    do {
        if (isPrime(i)) {
            printf("%d ", i);
        }
        i++;
    } while (i <= n);
    printf("\n");

    return 0;
}