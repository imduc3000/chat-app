#include <stdio.h>

int main() {
    int n, m, sc, product = 1; 
    printf("Please enter a number: ");
    scanf("%d", &n);
    m = n;
    while (n != 0)
    {
        sc = n % 10;
        product *= sc;
        n /= 10;
    }
    printf("Product of %d is: %d", m, product);

    return 0;

}