#include <stdio.h>

int main() {
    int num;
    printf("Enter an integer: ");
    scanf("%d", &num);
    
    if (num < 0) {
        printf("Please enter a positive number.\n");
        return 1;
    }
    
    if (num < 10) {
        printf("After swapping first and last digits: %d\n", num);
        return 0;
    }
    
    int last_digit = num % 10;
    int power = 1;
    while (num / power >= 10) {
        power *= 10;
    }
    
    int first_digit = num / power;
    int new_number = last_digit * power + (num % power) / 10 * 10 + first_digit;
    
    printf("After swapping first and last digits: %d\n", new_number);
    
    return 0;
}