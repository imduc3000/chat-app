#include <stdio.h>

int main() {
    int n, m, sc, sum = 0; 
    printf("Please enter a number: ");
    scanf("%d", &n);
    m = n;
    int sd = 0;
    while (n != 0)
    {
        /* 
        123
        Lan 1: 
        sc = 123 % 10 = 3
        sd = 3 + 0 * 10 = 3
        n = 123 / 10 = 12 (12 != 0)

        Lan 2
        sc = 12 % 10 = 2
        sd = 2 + 3 * 10 = 32
        n = 12 / 10 = 1 (1 != 0)

        Lan 3
        sc = 1 % 10 = 1
        sd = 1 + 32 * 10 = 321
        n = 1 / 10 = 0 (0 = 0 => break)
        */
        
        sc = n % 10;
        sd = sc + sd * 10;
        n /= 10;
    }
    printf("So dao cua %d la: %d", m, sd);

    return 0;

}