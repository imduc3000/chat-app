#include <stdio.h>

int main() {
    int n, m, sc, sum = 0; 
    printf("Please enter a number: ");
    scanf("%d", &n);
    m = n;
    while (n != 0)
    {
        sc = n % 10;
        sum += sc;
        n /= 10;
    }
    printf("Sum of %d is: %d", m, sum);

    return 0;

}