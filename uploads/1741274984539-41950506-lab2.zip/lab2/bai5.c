#include <stdio.h>

int main() {
    int n, first_digit, last_digit;
    printf("Please enter a number: ");
    scanf("%d", &n);

    first_digit = n / 10;
    last_digit = n % 10;
    while (first_digit > 10)
    {
        first_digit /= 10;
    }
    
    
    printf("First digit: %d \n", first_digit);
    printf("Last digit: %d \n", last_digit);


    
    return 0;
}