#include <stdio.h>

// Hàm tính giai thừa
long long factorial(int n) {
    long long result = 1;
    for (int i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}

int main() {
    int n;

    // Yêu cầu người dùng nhập số và kiểm tra đầu vào
    do {
        printf("Please enter a non-negative integer: ");
        scanf("%d", &n);

        if (n < 0) {
            printf("Invalid input. Please enter a non-negative integer.\n");
        }
    } while (n < 0); // Lặp lại nếu đầu vào không hợp lệ

    // Tính và in giai thừa
    printf("%d! = %lld\n", n, factorial(n));

    return 0;
}