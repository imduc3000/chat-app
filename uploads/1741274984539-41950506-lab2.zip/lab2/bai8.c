#include <stdio.h>

int main() {
    int n, m, sc, count = 0; 
    printf("Please enter a number: ");
    scanf("%d", &n);
    m = n;
    
    do {
        sc = n % 10;
        count += 1;
        n /= 10;
    } while (n != 0);
    
    printf("%d has %d numbers in it!", m, count);
    
    return 0;

}